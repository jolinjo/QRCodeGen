const API_URL = 'http://127.0.0.1:5002/generate';

const els = {
  status: document.getElementById('server-status'),
  data: document.getElementById('qr-data'),
  format: document.getElementById('format'),
  scale: document.getElementById('scale'),
  border: document.getElementById('border'),
  dark: document.getElementById('dark'),
  light: document.getElementById('light'),
  logo: document.getElementById('logo'),
  logoScale: document.getElementById('logo-scale'),
  button: document.getElementById('generate-btn'),
  message: document.getElementById('message'),
  previewContainer: document.getElementById('preview-container'),
  previewImage: document.getElementById('preview'),
  download: document.getElementById('download-link'),
};

async function checkServer() {
  try {
    const res = await fetch(API_URL, { method: 'OPTIONS' });
    if (res.ok) {
      els.status.textContent = '連線正常';
      els.status.classList.remove('status-off');
      els.status.classList.add('status-on');
    } else {
      throw new Error('status ' + res.status);
    }
  } catch (err) {
    els.status.textContent = '未連線';
    els.status.classList.remove('status-on');
    els.status.classList.add('status-off');
  }
}

async function readFileAsDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function setMessage(text, type = '') {
  els.message.textContent = text;
  els.message.className = type;
}

function resetResult() {
  els.previewContainer.classList.add('hidden');
  els.previewImage.src = '';
  els.download.classList.add('disabled');
  els.download.removeAttribute('href');
  els.download.removeAttribute('download');
  els.download.textContent = '下載檔案';
}

async function generate() {
  resetResult();
  const data = els.data.value.trim();
  if (!data) {
    setMessage('請輸入要編碼的文字或網址', 'error');
    return;
  }

  const payload = {
    data,
    format: els.format.value,
    scale: Number(els.scale.value) || 8,
    border: Number(els.border.value) || 4,
    dark: els.dark.value || '#000000',
    light: els.light.value || '#ffffff',
  };

  const logoRatio = parseFloat(els.logoScale.value);
  if (!Number.isNaN(logoRatio)) {
    const clamped = Math.min(Math.max(logoRatio, 0), 0.4);
    payload.logoScale = clamped;
    if (clamped !== logoRatio) {
      els.logoScale.value = clamped.toFixed(2);
    }
  }

  const file = els.logo.files?.[0];
  if (file) {
    const isSvg =
      file.type === 'image/svg+xml' ||
      file.name.toLowerCase().endsWith('.svg');
    if (!isSvg) {
      setMessage('請上傳 SVG 檔案作為 Logo', 'error');
      return;
    }
    payload.logo = await readFileAsDataURL(file);
  }

  try {
    els.button.disabled = true;
    setMessage('產生中...', '');

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const result = await response.json();

    if (!response.ok || result.status !== 'ok') {
      throw new Error(result.message || '無法產生 QR Code');
    }

    const label = payload.format.toUpperCase();
    setMessage(`產生成功！${label} 檔案已準備下載。`, 'success');

    const byteString = atob(result.data);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const uintArray = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i += 1) {
      uintArray[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([arrayBuffer], { type: result.mime });
    const url = URL.createObjectURL(blob);

    els.download.href = url;
    els.download.download = result.filename || `qrcode.${payload.format}`;
    els.download.classList.remove('disabled');
    els.download.textContent = `下載 ${label}`;

    if (payload.format === 'svg') {
      els.previewImage.src = url;
      els.previewContainer.classList.remove('hidden');
    } else {
      els.previewContainer.classList.add('hidden');
      els.previewImage.src = '';
    }
  } catch (error) {
    console.error(error);
    setMessage(error.message || '產生過程發生錯誤', 'error');
  } finally {
    els.button.disabled = false;
  }
}

els.button.addEventListener('click', () => {
  generate();
});

checkServer();
setInterval(checkServer, 5000);
