# Chrome 擴充功能：本地 Python QR Code 產生器

此版本專門用來呼叫本地的 Flask 服務 (`offline_generator/server_flask.py`) 產生 QR 碼，不再直接打 QRCode Monkey API。使用步驟：

1. 先啟動本地服務
   ```bash
   python3 -m pip install flask segno pillow cairosvg ezdxf
   python offline_generator/server_flask.py --port 5002
   ```

2. 在 Chrome 中載入擴充功能
   - 打開 `chrome://extensions`
   - 開啟「開發人員模式」
   - 點「載入未封裝項目」，選擇 `chrome-extension-local/`

3. 點擊擴充功能圖示 → 會在新分頁開啟 UI
   - 輸入網址或文字
   - 選擇格式（SVG / DXF）、顏色，可上傳 SVG Logo（自動縮放至中央留白區域）
   - 產生後即可預覽或下載（SVG 預覽支援 Logo，DXF 目前不內嵌 Logo）

> UI 在 `page.html` / `page.css` / `page.js`，若要調整操作行為或欄位，可直接修改這三個檔案。
